﻿local L = DataStore:SetLocale("Altoholic", "deDE")
if not L then return end

L["Calendar"] = "Kalender"