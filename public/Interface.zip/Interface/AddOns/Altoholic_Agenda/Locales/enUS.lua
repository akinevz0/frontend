local L = DataStore:SetDefaultLocale("Altoholic", "enUS")

-- ** Menu **
L["Calendar"] = true
