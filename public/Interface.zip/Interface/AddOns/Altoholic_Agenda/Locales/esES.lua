local L = DataStore:SetLocale("Altoholic", "esES")
if not L then return end

L["Calendar"] = "Calendario"