local L = DataStore:SetLocale("Altoholic", "esMX")
if not L then return end

L["Calendar"] = "Calendario"