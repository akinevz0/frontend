local L = DataStore:SetLocale("Altoholic", "frFR")
if not L then return end

L["Calendar"] = "Calendrier"