local L = DataStore:SetLocale("Altoholic", "itIT")
if not L then return end

L["Calendar"] = "Calendario"