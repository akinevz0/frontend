local L = DataStore:SetLocale("Altoholic", "koKR")
if not L then return end

L["Calendar"] = "달력"