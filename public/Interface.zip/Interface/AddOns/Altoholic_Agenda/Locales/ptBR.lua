local L = DataStore:SetLocale("Altoholic", "ptBR")
if not L then return end

L["Calendar"] = "Calendário"