-- 
-- Russian localization made by Hellbot & Interim @ EU Realms 
-- Перевод выполнен Хэлла и Интерим @ Азурегос 
--

local L = DataStore:SetLocale("Altoholic", "ruRU")
if not L then return end

L["Calendar"] = "Календарь"