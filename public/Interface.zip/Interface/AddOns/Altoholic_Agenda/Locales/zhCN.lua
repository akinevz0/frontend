local L = DataStore:SetLocale("Altoholic", "zhCN")
if not L then return end

L["Calendar"] = "日历"