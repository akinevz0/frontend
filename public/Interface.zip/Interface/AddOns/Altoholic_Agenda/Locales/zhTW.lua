local L = DataStore:SetLocale("Altoholic", "zhTW")
if not L then return end

L["Calendar"] = "日曆"